import Image from "next/image";
import {
  ArrowUpRight,
  Phone,
  Compass,
  Layers,
  Shield,
  Sparkles,
} from "lucide-react";
import { site, divisions, metrics, processSteps, serviceNames } from "@/lib/site";
import Navbar from "@/components/Navbar";
import InteractiveWorkspace from "@/components/InteractiveWorkspace";

const wa = `https://wa.me/${site.whatsapp}`;

export default function Home() {
  return (
    <div id="top" className="min-h-screen bg-obsidian text-ivory">
      <Navbar />

      <main>
        {/* HERO SECTION */}
        <section className="relative overflow-hidden architectural-grid pt-32 pb-20 sm:pt-40 sm:pb-28">
          {/* Ambient radial glow & burgundy accent */}
          <div className="pointer-events-none absolute inset-0 bg-radial-glow" />
          <div className="pointer-events-none absolute -top-40 right-0 h-[520px] w-[520px] rounded-full bg-burgundy/30 blur-[140px]" />

          <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
            <div className="grid items-center gap-12 lg:grid-cols-[1.15fr_0.85fr]">
              {/* Left Column: Editorial Headline */}
              <div>
                <div className="inline-flex items-center gap-2.5 rounded-full border border-gold/30 bg-burgundy/40 px-4 py-1.5 backdrop-blur-md">
                  <span className="h-2 w-2 rounded-full bg-amber" />
                  <span className="font-mono text-xs uppercase tracking-[0.22em] text-gold">
                    {site.tagline} · Integrated Solutions
                  </span>
                </div>

                <h1 className="mt-7 font-display text-5xl font-extrabold leading-[0.98] tracking-tight text-ivory sm:text-6xl lg:text-7xl">
                  Plan it.{" "}
                  <span className="bg-gradient-to-r from-ivory via-gold to-amber-light bg-clip-text text-transparent">
                    Build it.
                  </span>{" "}
                  Keep it standing.
                </h1>

                <p className="mt-7 max-w-xl text-base leading-relaxed text-ivory/75 sm:text-lg">
                  SG Wurld unites architectural drawing, turnkey building construction, hybrid solar engineering, wholesale building materials, real estate, heavy-duty logistics, and luxury lifestyle services—so one call moves your entire vision forward.
                </p>

                <div className="mt-9 flex flex-wrap items-center gap-4">
                  <a
                    href={wa}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2.5 rounded-full bg-amber px-7 py-4 text-sm font-bold uppercase tracking-wider text-obsidian shadow-xl shadow-amber/25 transition hover:bg-amber-light"
                  >
                    <span>Start on WhatsApp</span>
                    <ArrowUpRight className="h-4 w-4" />
                  </a>
                  <a
                    href="#catalog"
                    className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/5 px-7 py-4 text-sm font-semibold text-ivory backdrop-blur-md transition hover:border-gold/50 hover:bg-white/10"
                  >
                    <span>Explore 11 Services</span>
                  </a>
                </div>

                {/* Architectural Scale Rule */}
                <div className="mt-14 flex items-center gap-4 text-gold/70" aria-hidden="true">
                  <span className="font-mono text-[11px] uppercase tracking-widest">
                    01 // ARCHITECTURE
                  </span>
                  <span className="h-px flex-1 bg-gradient-to-r from-gold/40 via-white/15 to-transparent" />
                  <span className="font-mono text-[11px] uppercase tracking-widest">
                    02 // SUPPLY
                  </span>
                  <span className="h-px flex-1 bg-gradient-to-r from-white/15 via-gold/40 to-transparent" />
                  <span className="font-mono text-[11px] uppercase tracking-widest">
                    03 // LIFESTYLE
                  </span>
                </div>
              </div>

              {/* Right Column: Architectural Visual Showcase Card */}
              <div className="relative">
                <div className="relative overflow-hidden rounded-3xl border border-white/15 bg-surface shadow-2xl">
                  <div className="relative aspect-[4/4.6] w-full">
                    <Image
                      src="https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=85"
                      alt="Modern architectural residence representing SG Wurld Aesthetic Life"
                      fill
                      priority
                      className="object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-obsidian via-obsidian/30 to-transparent" />
                  </div>

                  {/* Floating Glass Spec Badge */}
                  <div className="absolute inset-x-5 bottom-5 rounded-2xl border border-white/15 bg-obsidian/85 p-5 backdrop-blur-xl">
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-[11px] uppercase tracking-[0.2em] text-gold">
                        Turnkey Execution
                      </span>
                      <span className="rounded-full bg-amber/20 px-2.5 py-0.5 font-mono text-[10px] font-semibold text-amber-light">
                        {site.phoneDisplay}
                      </span>
                    </div>
                    <p className="mt-2 font-display text-lg font-bold text-ivory">
                      Blueprint, Solar, Materials & Real Estate
                    </p>
                    <p className="mt-1 text-xs text-muted">
                      Complete lifecycle engineering with dedicated maintenance across every division.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Key Metrics Strip */}
            <div className="mt-16 grid grid-cols-2 gap-4 lg:grid-cols-4">
              {metrics.map((m) => (
                <div
                  key={m.label}
                  className="glass-panel rounded-2xl p-6"
                >
                  <div className="font-display text-3xl font-extrabold text-ivory sm:text-4xl">
                    {m.value}
                  </div>
                  <div className="mt-1.5 text-sm font-semibold text-gold">
                    {m.label}
                  </div>
                  <div className="mt-0.5 text-xs text-muted">{m.detail}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* MARQUEE CAPABILITIES RIBBON */}
        <div className="overflow-hidden border-y border-white/10 bg-burgundy/45 py-3.5">
          <div className="flex w-max animate-marquee items-center gap-8">
            {[...serviceNames, ...serviceNames].map((item, idx) => (
              <div key={`${item}-${idx}`} className="flex items-center gap-8">
                <span className="font-mono text-xs font-medium uppercase tracking-[0.2em] text-ivory/90">
                  {item}
                </span>
                <Sparkles className="h-3.5 w-3.5 text-amber" />
              </div>
            ))}
          </div>
        </div>

        {/* THREE CORE PILLARS / DIVISIONS */}
        <section id="divisions" className="relative bg-obsidian py-24 sm:py-32">
          <div className="mx-auto max-w-7xl px-5 sm:px-8">
            <div className="max-w-2xl">
              <span className="font-mono text-xs uppercase tracking-[0.25em] text-gold">
                Core Ecosystem
              </span>
              <h2 className="mt-3 font-display text-4xl font-extrabold tracking-tight text-ivory sm:text-5xl">
                Three specialized divisions. One unified standard.
              </h2>
              <p className="mt-4 text-base text-muted">
                Designed to eliminate contractor fragmentation—combining structural engineering, wholesale materials, and executive property & lifestyle services.
              </p>
            </div>

            <div className="mt-14 grid gap-8 lg:grid-cols-3">
              {divisions.map((div) => (
                <article
                  key={div.id}
                  className="glass-panel glass-panel-hover group overflow-hidden rounded-3xl flex flex-col justify-between"
                >
                  <div>
                    <div className="relative h-60 w-full overflow-hidden">
                      <Image
                        src={div.image}
                        alt={div.name}
                        fill
                        className="object-cover transition-transform duration-700 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-surface via-surface/35 to-transparent" />
                      <span className="absolute left-5 top-5 rounded-full border border-white/20 bg-obsidian/80 px-3.5 py-1 font-mono text-xs font-semibold text-gold backdrop-blur-md">
                        DIVISION {div.code}
                      </span>
                    </div>

                    <div className="p-7">
                      <h3 className="font-display text-2xl font-bold text-ivory">
                        {div.name}
                      </h3>
                      <p className="mt-1 font-mono text-xs uppercase tracking-wider text-amber-light">
                        {div.subtitle}
                      </p>
                      <p className="mt-4 text-sm leading-relaxed text-muted">
                        {div.description}
                      </p>

                      <div className="mt-6 flex flex-wrap gap-2">
                        {div.services.map((s) => (
                          <span
                            key={s.id}
                            className="rounded-lg border border-white/10 bg-white/[0.03] px-2.5 py-1 text-xs text-ivory/85"
                          >
                            {s.title}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="border-t border-white/10 px-7 py-4">
                    <a
                      href="#catalog"
                      className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-gold transition group-hover:text-amber-light"
                    >
                      <span>View Division Specs</span>
                      <ArrowUpRight className="h-4 w-4" />
                    </a>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* HOW WE WORK / EXECUTION PROCESS */}
        <section id="process" className="border-t border-white/10 bg-obsidian py-24">
          <div className="mx-auto max-w-7xl px-5 sm:px-8">
            <div className="grid gap-12 lg:grid-cols-[1fr_2fr] lg:items-center">
              <div>
                <span className="font-mono text-xs uppercase tracking-[0.25em] text-gold">
                  Seamless Delivery
                </span>
                <h2 className="mt-3 font-display text-3xl font-extrabold tracking-tight text-ivory sm:text-4xl">
                  Built for speed, clarity, and longevity.
                </h2>
                <p className="mt-4 text-sm leading-relaxed text-muted">
                  Whether commissioning an architectural blueprint, ordering bulk cement and roofing iron, or booking a 5-star stay, our workflow stays direct and accountable.
                </p>
                <div className="mt-7 flex items-center gap-4 text-xs text-ivory/80">
                  <span className="flex items-center gap-1.5">
                    <Compass className="h-4 w-4 text-amber" /> Precision Plans
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Layers className="h-4 w-4 text-amber" /> Verified Stock
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Shield className="h-4 w-4 text-amber" /> Full Maintenance
                  </span>
                </div>
              </div>

              <div className="grid gap-5 sm:grid-cols-3">
                {processSteps.map((item) => (
                  <div
                    key={item.step}
                    className="glass-panel rounded-2xl p-6"
                  >
                    <span className="font-display text-3xl font-extrabold text-amber">
                      {item.step}
                    </span>
                    <h3 className="mt-4 font-display text-lg font-bold text-ivory">
                      {item.title}
                    </h3>
                    <p className="mt-2 text-xs leading-relaxed text-muted">
                      {item.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* INTERACTIVE CATALOG & QUOTE WORKSPACE */}
        <InteractiveWorkspace />
      </main>

      {/* LUXURY FOOTER */}
      <footer className="border-t border-white/10 bg-obsidian pt-16 pb-10 text-ivory">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <div className="grid gap-10 pb-12 border-b border-white/10 md:grid-cols-2 lg:grid-cols-4">
            <div className="lg:col-span-2">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-gold/40 bg-burgundy font-display text-base font-extrabold text-ivory">
                  SG
                </div>
                <div>
                  <span className="font-display text-xl font-extrabold tracking-tight">
                    {site.name}
                  </span>
                  <span className="block font-mono text-[10px] uppercase tracking-[0.24em] text-gold">
                    {site.tagline}
                  </span>
                </div>
              </div>
              <p className="mt-4 max-w-md text-sm leading-relaxed text-muted">
                Architectural design, construction, electrical & solar energy, building materials, automotive restoration, real estate, heavy-duty truck charter, 5-star hospitality, and bespoke event styling.
              </p>
            </div>

            <div>
              <h4 className="font-mono text-xs uppercase tracking-[0.2em] text-gold">
                Navigation
              </h4>
              <ul className="mt-4 space-y-2.5 text-sm text-ivory/75">
                <li><a href="#divisions" className="hover:text-ivory">Core Divisions</a></li>
                <li><a href="#catalog" className="hover:text-ivory">Service Catalog</a></li>
                <li><a href="#process" className="hover:text-ivory">Execution Process</a></li>
                <li><a href="#contact" className="hover:text-ivory">Request a Quote</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-mono text-xs uppercase tracking-[0.2em] text-gold">
                Direct Desk
              </h4>
              <ul className="mt-4 space-y-2.5 text-sm text-ivory/75">
                <li>
                  <a href={`tel:${site.phone}`} className="inline-flex items-center gap-2 hover:text-amber-light">
                    <Phone className="h-3.5 w-3.5 text-amber" />
                    {site.phoneDisplay}
                  </a>
                </li>
                <li>
                  <a href={`mailto:${site.email}`} className="hover:text-ivory">
                    {site.email}
                  </a>
                </li>
                <li>
                  <a href={site.instagram} target="_blank" rel="noopener noreferrer" className="hover:text-ivory">
                    Instagram: @sgwurld
                  </a>
                </li>
                <li>
                  <a href={site.facebook} target="_blank" rel="noopener noreferrer" className="hover:text-ivory">
                    Facebook: SG Wurld
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="mt-8 flex flex-col items-center justify-between gap-4 text-xs text-muted sm:flex-row">
            <p>© {new Date().getFullYear()} {site.name} ({site.tagline}). All rights reserved.</p>
            <p className="font-mono text-[11px] uppercase tracking-widest text-gold/80">
              Plan It · Build It · Keep It Standing
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
