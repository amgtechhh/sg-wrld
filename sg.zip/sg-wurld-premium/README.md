# SG Wurld — Aesthetic Life (Premium Edition)

Next.js 14 (App Router), TypeScript, Tailwind CSS, and Lucide Icons.

## Getting Started

```bash
npm install
npm run dev      # http://localhost:3000
npm run build && npm start
```

## Customization
- Edit business contact details, divisions, and service specs in `lib/site.ts`.
- Replace `site.facebook` in `lib/site.ts` once the dedicated Facebook page URL is ready.
