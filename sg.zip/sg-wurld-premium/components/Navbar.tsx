"use client";

import { useState, useEffect } from "react";
import { Menu, X, ArrowUpRight, Phone } from "lucide-react";
import { site } from "@/lib/site";

const wa = `https://wa.me/${site.whatsapp}`;

const navLinks = [
  { label: "Divisions", href: "#divisions" },
  { label: "Catalog", href: "#catalog" },
  { label: "Process", href: "#process" },
  { label: "Contact", href: "#contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 28);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled
          ? "border-b border-white/10 bg-obsidian/85 py-3 backdrop-blur-xl shadow-2xl"
          : "bg-transparent py-5"
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 sm:px-8">
        {/* Brand Monogram & Wordmark */}
        <a href="#top" className="group flex items-center gap-3">
          <div className="relative flex h-10 w-10 items-center justify-center rounded-lg border border-gold/40 bg-gradient-to-br from-burgundy to-obsidian shadow-inner transition-transform duration-300 group-hover:scale-105">
            <span className="font-display text-base font-extrabold tracking-tighter text-ivory">
              SG
            </span>
            <span className="absolute -bottom-0.5 -right-0.5 h-2 w-2 rounded-full bg-amber" />
          </div>
          <div className="flex flex-col">
            <span className="font-display text-xl font-extrabold tracking-tight text-ivory leading-none">
              {site.name}
            </span>
            <span className="mt-1 font-mono text-[10px] uppercase tracking-[0.24em] text-gold">
              {site.tagline}
            </span>
          </div>
        </a>

        {/* Desktop Nav */}
        <nav className="hidden items-center gap-8 md:flex">
          {navLinks.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="text-sm font-medium text-ivory/75 transition-colors hover:text-ivory"
            >
              {item.label}
            </a>
          ))}
        </nav>

        {/* Actions */}
        <div className="hidden items-center gap-3 md:flex">
          <a
            href={`tel:${site.phone}`}
            className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-2 text-xs font-semibold text-ivory transition hover:border-white/30 hover:bg-white/10"
          >
            <Phone className="h-3.5 w-3.5 text-gold" />
            <span>{site.phoneDisplay}</span>
          </a>
          <a
            href={wa}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 rounded-full bg-amber px-5 py-2 text-xs font-bold uppercase tracking-wider text-obsidian transition hover:bg-amber-light shadow-lg shadow-amber/20"
          >
            <span>WhatsApp Desk</span>
            <ArrowUpRight className="h-4 w-4" />
          </a>
        </div>

        {/* Mobile Menu Toggle */}
        <button
          type="button"
          onClick={() => setMobileOpen((prev) => !prev)}
          aria-label="Toggle navigation menu"
          className="flex h-10 w-10 items-center justify-center rounded-lg border border-white/15 bg-surface text-ivory md:hidden"
        >
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="border-b border-white/10 bg-charcoal/98 px-5 pb-6 pt-4 backdrop-blur-2xl md:hidden">
          <nav className="flex flex-col space-y-3">
            {navLinks.map((item) => (
              <a
                key={item.href}
                href={item.href}
                onClick={() => setMobileOpen(false)}
                className="rounded-lg px-3 py-2.5 text-base font-medium text-ivory/90 transition hover:bg-white/5"
              >
                {item.label}
              </a>
            ))}
          </nav>
          <div className="mt-5 grid grid-cols-2 gap-3 border-t border-white/10 pt-5">
            <a
              href={`tel:${site.phone}`}
              className="flex items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/5 py-3 text-xs font-semibold text-ivory"
            >
              <Phone className="h-3.5 w-3.5 text-gold" />
              Call Now
            </a>
            <a
              href={wa}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-1.5 rounded-xl bg-amber py-3 text-xs font-bold uppercase tracking-wider text-obsidian"
            >
              WhatsApp
              <ArrowUpRight className="h-4 w-4" />
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
