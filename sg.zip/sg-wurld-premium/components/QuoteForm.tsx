"use client";

import { useState, useEffect, type FormEvent } from "react";
import { Send, MapPin, Calendar, Layers, User } from "lucide-react";
import { site, serviceNames } from "@/lib/site";

interface QuoteFormProps {
  selectedService?: string;
}

const inputBase =
  "w-full rounded-xl border border-white/12 bg-obsidian/90 px-4 py-3 text-sm text-ivory placeholder:text-muted/60 transition focus:border-amber focus:outline-none focus:ring-1 focus:ring-amber";

export default function QuoteForm({ selectedService }: QuoteFormProps) {
  const [name, setName] = useState("");
  const [service, setService] = useState(serviceNames[0]);
  const [location, setLocation] = useState("");
  const [timeline, setTimeline] = useState("Immediate / This Week");
  const [details, setDetails] = useState("");

  useEffect(() => {
    if (selectedService && serviceNames.includes(selectedService)) {
      setService(selectedService);
    }
  }, [selectedService]);

  function send(e: FormEvent) {
    e.preventDefault();
    const lines = [
      `Hello *${site.name}*,`,
      ``,
      `*Client Name:* ${name}`,
      `*Service Needed:* ${service}`,
      location ? `*Location:* ${location}` : null,
      `*Timeline:* ${timeline}`,
      details ? `*Project Brief:* ${details}` : null,
    ].filter(Boolean);

    const text = lines.join("\n");
    window.open(
      `https://wa.me/${site.whatsapp}?text=${encodeURIComponent(text)}`,
      "_blank",
      "noopener,noreferrer"
    );
  }

  return (
    <form
      onSubmit={send}
      className="glass-panel rounded-3xl p-6 sm:p-8 shadow-2xl"
    >
      <div className="mb-6 flex items-center justify-between border-b border-white/10 pb-4">
        <div>
          <span className="font-mono text-[11px] uppercase tracking-[0.2em] text-gold">
            Direct Project Dispatch
          </span>
          <h3 className="mt-1 font-display text-2xl font-bold text-ivory">
            Request an Instant Quote
          </h3>
        </div>
        <span className="flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 font-mono text-[11px] text-emerald-400">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
          Online
        </span>
      </div>

      <div className="space-y-4">
        <div>
          <label className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-ivory/80">
            <User className="h-3.5 w-3.5 text-gold" />
            <span>Your Full Name</span>
          </label>
          <input
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            className={inputBase}
            placeholder="e.g. Ibrahim Musa"
          />
        </div>

        <div>
          <label className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-ivory/80">
            <Layers className="h-3.5 w-3.5 text-gold" />
            <span>Select Division / Service</span>
          </label>
          <select
            value={service}
            onChange={(e) => setService(e.target.value)}
            className={inputBase}
          >
            {serviceNames.map((s) => (
              <option key={s} value={s} className="bg-charcoal text-ivory">
                {s}
              </option>
            ))}
          </select>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-ivory/80">
              <MapPin className="h-3.5 w-3.5 text-gold" />
              <span>Site / Delivery Location</span>
            </label>
            <input
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className={inputBase}
              placeholder="City, district or site address"
            />
          </div>

          <div>
            <label className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-ivory/80">
              <Calendar className="h-3.5 w-3.5 text-gold" />
              <span>Target Timeline</span>
            </label>
            <select
              value={timeline}
              onChange={(e) => setTimeline(e.target.value)}
              className={inputBase}
            >
              <option value="Immediate / This Week" className="bg-charcoal">
                Immediate / This Week
              </option>
              <option value="Within 2 – 4 Weeks" className="bg-charcoal">
                Within 2 – 4 Weeks
              </option>
              <option value="1 – 3 Months" className="bg-charcoal">
                1 – 3 Months
              </option>
              <option value="Budgeting & Consultation" className="bg-charcoal">
                Budgeting & Consultation
              </option>
            </select>
          </div>
        </div>

        <div>
          <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-ivory/80">
            Scope, Quantities or Specifications
          </label>
          <textarea
            rows={4}
            value={details}
            onChange={(e) => setDetails(e.target.value)}
            className={inputBase}
            placeholder="Describe your architectural plot size, material quantities, solar kVA requirement, property preference, or event date..."
          />
        </div>

        <button
          type="submit"
          className="group mt-2 flex w-full items-center justify-center gap-2.5 rounded-xl bg-amber px-6 py-4 text-sm font-bold uppercase tracking-wider text-obsidian shadow-xl shadow-amber/20 transition hover:bg-amber-light"
        >
          <span>Transmit Brief via WhatsApp</span>
          <Send className="h-4 w-4 transition-transform group-hover:translate-x-1" />
        </button>

        <p className="text-center text-xs text-muted">
          Pre-formats your project brief directly to{" "}
          <span className="font-mono text-ivory/90">{site.phoneDisplay}</span>.
        </p>
      </div>
    </form>
  );
}
